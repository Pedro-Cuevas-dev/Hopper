<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CotiEx</title>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">

    <!--box icons link-->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <!--google fonts link-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Michroma&family=MuseoModerno:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header-->

    <header>
        <a href="#" class="logo"><i class='bx bxs-diamond'></i>Hopper</a>

        <ul class="navlist">
            <li><a href="index.php" class="active">Inicio</a></li>
            <li><a href="acerca.php">Acerca de nosotros</a></li>
            <li><a href="Tienda.php">Tienda</a></li>
            <li><a href="panel_administrador.php">Administración</a></li>
            <li><a href="regist.php">Registrate</a></li>
            <li><a href="Login.php">Iniciar Sesión</a></li>
        </ul>

        <div class="h-main">
            <a href="#" class="h-btn">Buy Now</a>
            <div class="bx bx-menu" id="menu-icon"></div>
            <div class="bx bx-moon" id="darkmode"></div>
        </div>
    </header>
    <!--header end-->
</body>
</html>