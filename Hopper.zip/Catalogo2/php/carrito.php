<?php

require_once 'config.php';

session_start();

// Agregar producto al carrito
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_al_carrito'])) {
    $productoId = $_POST['producto_id'];
    $cantidad = $_POST['cantidad'];

    // Verificar el stock disponible
    $sql_stock = "SELECT stock FROM productos WHERE id_producto = ?";
    $stmt_stock = $conn->prepare($sql_stock);
    $stmt_stock->bind_param("i", $productoId);
    $stmt_stock->execute();
    $result_stock = $stmt_stock->get_result();
    $producto_stock = $result_stock->fetch_assoc();

    if (!$producto_stock || $producto_stock['stock'] < $cantidad) {
        echo json_encode(['status' => 'error', 'message' => 'Stock insuficiente']);
        exit;
    }

    // Obtener detalles del producto
    $sql_producto = "SELECT * FROM productos WHERE id_producto = ?";
    $stmt_producto = $conn->prepare($sql_producto);
    $stmt_producto->bind_param("i", $productoId);
    $stmt_producto->execute();
    $result_producto = $stmt_producto->get_result();
    $producto = $result_producto->fetch_assoc();

    if ($producto) {
        $producto['cantidad'] = $cantidad;
        $_SESSION['carrito'][$productoId] = $producto;

        // Actualizar el stock en la base de datos
        $nuevo_stock = $producto_stock['stock'] - $cantidad;
        $sql_actualizar_stock = "UPDATE productos SET stock = ? WHERE id_producto = ?";
        $stmt_actualizar_stock = $conn->prepare($sql_actualizar_stock);
        $stmt_actualizar_stock->bind_param("ii", $nuevo_stock, $productoId);
        $stmt_actualizar_stock->execute();

        echo json_encode(['status' => 'success', 'message' => 'Producto agregado al carrito']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Producto no encontrado']);
    }
    exit;
}


// Otras operaciones del carrito pueden ir aquí

?>
